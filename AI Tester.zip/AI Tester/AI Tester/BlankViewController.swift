//
//  BlankViewController.swift
//  AI Tester
//
//  Created by Andrei Sadovnicov on 06/04/16.
//  Copyright © 2016 Andrei Sadovnicov. All rights reserved.
//

import UIKit

class BlankViewController: UIViewController {

    // MARK: - White status bar
    override var preferredStatusBarStyle : UIStatusBarStyle {
        
        return UIStatusBarStyle.lightContent
        
    }

}
