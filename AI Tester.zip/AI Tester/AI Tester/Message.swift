//
//  Message.swift
//  AI Tester
//
//  Created by Andrei Sadovnicov on 14/04/16.
//  Copyright © 2016 Andrei Sadovnicov. All rights reserved.
//

import Foundation
import CoreData


class Message: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
